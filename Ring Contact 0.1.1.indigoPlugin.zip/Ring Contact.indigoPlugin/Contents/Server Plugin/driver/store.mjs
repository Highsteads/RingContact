import { randomBytes } from "node:crypto";
import {
  chmodSync,
  linkSync,
  mkdirSync,
  readFileSync,
  renameSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { join } from "node:path";

const keyNames = ["S2_AccessControl", "S2_Authenticated", "S2_Unauthenticated", "S0_Legacy"];

function writeViaTemp(path, data, publish) {
  const temporary = `${path}.${randomBytes(8).toString("hex")}.tmp`;
  try {
    writeFileSync(temporary, JSON.stringify(data), { mode: 0o600, flag: "wx" });
    publish(temporary, path);
  } finally {
    rmSync(temporary, { force: true });
  }
}

function readJson(path) {
  return JSON.parse(readFileSync(path, "utf8"));
}

export function openStore(directory) {
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const keyFile = join(directory, "network-keys.json");
  let stored;
  try {
    stored = readJson(keyFile);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    const keys = Object.fromEntries(keyNames.map(name => [name, randomBytes(16).toString("hex")]));
    try {
      // A second process opening the store must reuse the first process's keys.
      writeViaTemp(keyFile, keys, linkSync);
    } catch (linkError) {
      if (linkError.code !== "EEXIST") throw linkError;
    }
    stored = readJson(keyFile);
  }
  if (!stored || !keyNames.every(name => typeof stored[name] === "string" && /^[0-9a-f]{32}$/i.test(stored[name]))) {
    throw new Error("Invalid stored Z-Wave keys");
  }
  chmodSync(keyFile, 0o600);
  return Object.fromEntries(keyNames.map(name => [name, Buffer.from(stored[name], "hex")]));
}

export function openObservations(directory, homeId) {
  const path = join(directory, `observations-${homeId}.json`);
  let records = {};
  try {
    const saved = readJson(path);
    if (!saved || typeof saved !== "object" || Array.isArray(saved)) {
      throw new Error("Invalid saved sensor states");
    }
    records = saved;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }

  let dirty = false;
  return {
    get(nodeId, identity) {
      const record = records[nodeId];
      if (identity === null || record?.identity !== identity) return undefined;
      return record;
    },
    update(nodeId, identity, values) {
      const previous = this.get(nodeId, identity);
      if (!identity || Object.entries(values).every(([key, value]) => previous?.[key] === value)) return false;
      records[nodeId] = { ...previous, ...values, identity };
      dirty = true;
      return true;
    },
    remove(nodeId) {
      if (Object.hasOwn(records, nodeId)) {
        delete records[nodeId];
        dirty = true;
      }
    },
    save() {
      if (dirty) writeViaTemp(path, records, renameSync);
      dirty = false;
    },
  };
}
