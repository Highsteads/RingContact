import { statSync } from "node:fs";
import { isAbsolute, join, resolve } from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { SecurityClass } from "@zwave-js/core";
import {
  Driver,
  InclusionState,
  InclusionStrategy,
  RemoveNodeReason,
  ZWaveErrorCodes,
} from "zwave-js";
import { describeNode, inspectReport, isRingContact, nodeIdentity } from "./ring.mjs";
import { openObservations, openStore } from "./store.mjs";

const operationTimeout = 60_000;

function writeMessage(stream, message) {
  stream.write(`${JSON.stringify(message)}\n`);
}

function readOptions() {
  const { values } = parseArgs({
    options: {
      port: { type: "string" },
      store: { type: "string" },
    },
  });
  if (!values.port?.startsWith("/dev/") || !values.store || !isAbsolute(values.store)) {
    throw new Error("Expected a local USB port and an absolute storage directory");
  }
  return values;
}

export async function serve({ port, store }, {
  inputStream = process.stdin,
  outputStream = process.stdout,
  createDriver = (serialPort, options) => new Driver(serialPort, options),
  setExitCode = code => { process.exitCode = code; },
} = {}) {
  const send = message => writeMessage(outputStream, message);
  const status = message => send({ type: "status", message });
  const error = message => send({ type: "error", message });
  try {
    if (!statSync(port).isCharacterDevice()) throw new Error("Not a serial device");
  } catch {
    error("The selected USB port is unavailable. Connect the dedicated Z-Wave stick and check the port in plugin settings.");
    setExitCode(1);
    return;
  }

  let keys;
  try {
    keys = openStore(store);
  } catch {
    error("Z-Wave security settings could not be read or created. Keep the existing keys and check the driver's storage folder.");
    setExitCode(1);
    return;
  }

  const driver = createDriver(port, {
    securityKeys: keys,
    storage: { cacheDir: join(store, "cache") },
    logConfig: { enabled: false, logToFile: false, showLogo: false },
  });
  const stdoutAbort = new AbortController();
  const published = new Map();
  let homeId;
  let observations;
  let input;
  let active;
  let stopping = false;
  let storageWarning = false;

  function trySave() {
    try {
      observations?.save();
      storageWarning = false;
    } catch {
      if (!storageWarning) error("Indigo could not save the last sensor readings. Check the driver's storage folder.");
      storageWarning = true;
    }
  }

  function describe(node) {
    return describeNode(node, observations?.get(node.id, nodeIdentity(node)));
  }

  function publish(node) {
    if (!homeId || stopping || !isRingContact(node)) return;
    const details = describe(node);
    const fingerprint = JSON.stringify(details);
    if (published.get(node.id) === fingerprint) return;
    published.set(node.id, fingerprint);
    send({ type: "node", homeId, node: details });
  }

  function snapshot() {
    if (!homeId) return;
    const nodes = [...driver.controller.nodes.values()].filter(isRingContact).map(describe);
    published.clear();
    for (const node of nodes) published.set(node.nodeId, JSON.stringify(node));
    send({ type: "snapshot", homeId, nodes });
  }

  function clearOperation() {
    if (active) {
      clearTimeout(active.timer);
      active.pin = undefined;
      active = undefined;
    }
  }

  async function stop(exitCode) {
    if (stopping) return;
    stopping = true;
    setExitCode(exitCode);
    clearOperation();
    stdoutAbort.abort();
    input?.close();
    inputStream.pause();
    trySave();
    try {
      await driver.destroy();
    } catch {
      setExitCode(1);
    }
  }

  function onReport(nodeId, values) {
    if (stopping || !homeId || !observations) return;
    const node = driver.controller.nodes.get(nodeId);
    if (!isRingContact(node) || node.getHighestSecurityClass() !== SecurityClass.S2_Authenticated) return;
    if (observations.update(nodeId, nodeIdentity(node), values)) {
      publish(node);
      trySave();
    }
  }

  async function cancelOperation() {
    if (!active) {
      status("No pairing or removal is in progress.");
      return;
    }
    const controller = driver.controller;
    const pending = active;
    pending.pin = undefined;
    const stopped = pending.command === "include" ? await controller.stopInclusion() : await controller.stopExclusion();
    if (active !== pending) return;
    if (stopped || controller.inclusionState === InclusionState.Idle || controller.inclusionState === InclusionState.SmartStart) {
      clearOperation();
      status(pending.command === "include" ? "Pairing mode ended." : "Removal mode ended.");
    } else {
      status("The stick is finishing the current operation. Wait a moment before trying again.");
    }
  }

  async function beginOperation(message) {
    if (active) throw new Error("Finish or cancel the current pairing or removal first.");
    const { command, pin } = message;
    if (command === "include" && (typeof pin !== "string" || !/^\d{5}$/.test(pin) || Number(pin) > 65535)) {
      throw new Error("Enter the five digits printed next to the Ring sensor’s QR code.");
    }
    const controller = driver.controller;
    const pending = { command, pin };
    active = pending;
    let started;
    try {
      started = command === "include"
        ? await controller.beginInclusion({
            strategy: InclusionStrategy.Security_S2,
            userCallbacks: {
              async grantSecurityClasses(requested) {
                if (active !== pending || !pending.pin || !requested.securityClasses.includes(SecurityClass.S2_Authenticated)) {
                  return false;
                }
                return { securityClasses: [SecurityClass.S2_Authenticated], clientSideAuth: false };
              },
              async validateDSKAndEnterPIN() {
                if (active !== pending) return false;
                const digits = pending.pin;
                pending.pin = undefined;
                return digits ?? false;
              },
              abort() {
                pending.pin = undefined;
              },
            },
          })
        : await controller.beginExclusion();
    } catch {
      if (active === pending) clearOperation();
      throw new Error("The Z-Wave stick could not start the requested operation.");
    }
    if (!started) {
      if (active === pending) clearOperation();
      throw new Error("The Z-Wave stick is busy or unavailable. Try again after it is ready.");
    }
    if (active !== pending) return;
    status(command === "include"
      ? "Pairing started. Hold the button on the front of the Ring sensor for about three seconds."
      : "Removal mode started. Briefly press the button in the pinhole on the back of the Ring sensor.");
    pending.timer = setTimeout(() => {
      if (active !== pending) return;
      pending.pin = undefined;
      void cancelOperation().catch(() => error("The stick could not cancel the operation. Restart the plugin before trying again."));
    }, operationTimeout);
    pending.timer.unref();
  }

  async function handle(message) {
    if (!message || typeof message !== "object" || stopping) return;
    if (message.command === "stop") {
      await stop(0);
      return;
    }
    if (!homeId) {
      error("Wait for the Z-Wave stick to finish starting.");
      return;
    }
    switch (message.command) {
      case "snapshot":
        snapshot();
        break;
      case "include":
      case "exclude":
        await beginOperation(message);
        break;
      case "cancel":
        await cancelOperation();
        break;
      default:
        error("The driver received an unknown request.");
    }
  }

  driver.on("error", failure => {
    if (stopping) return;
    error("The Z-Wave stick reported a communication problem. Check the selected port and that the stick is free.");
    if (!homeId || failure.code === ZWaveErrorCodes.Driver_Failed || failure.code === ZWaveErrorCodes.Driver_SerialPortClosed) {
      void stop(1);
    }
  });

  driver.on("driver ready", () => {
    homeId = (driver.controller.homeId >>> 0).toString(16).padStart(8, "0");
    try {
      observations = openObservations(store, homeId);
    } catch {
      error("The saved sensor readings could not be opened. Check the driver's storage folder before restarting.");
      void stop(1);
      return;
    }

    snapshot();
    status("Z-Wave stick ready.");
    const controller = driver.controller;
    controller.on("node found", () => {
      if (active?.command === "include") clearTimeout(active.timer);
    });
    controller.on("node added", (node, result) => {
      if (active?.command === "include") {
        if (result.lowSecurity || node.getHighestSecurityClass() !== SecurityClass.S2_Authenticated) {
          error("The sensor did not pair securely. Remove it and try again with the five-digit code from that sensor.");
        } else {
          status("Sensor paired securely. Waiting for it to finish setting up.");
        }
        clearOperation();
      }
      publish(node);
    });
    controller.on("node removed", (node, reason) => {
      observations.remove(node.id);
      trySave();
      if (published.delete(node.id) || isRingContact(node)) {
        send({ type: "removed", homeId, nodeId: node.id });
        if (reason === RemoveNodeReason.Reset) {
          status("A Ring sensor was reset and left the Z-Wave network.");
        }
      }
    });
    controller.on("inclusion failed", () => {
      clearOperation();
      error("Pairing failed. Wake the sensor and try again.");
    });
    controller.on("exclusion failed", () => {
      clearOperation();
      error("Removal failed. Briefly press the sensor's rear pinhole button after starting removal.");
    });
    // Z-Wave JS stops controller discovery before it starts the S2 exchange.
    // Keep the pairing PIN until node added, failure, or explicit cancellation.
    controller.on("exclusion stopped", () => {
      if (active?.command === "exclude") {
        clearOperation();
        status("Removal mode ended. A solid red light on the Ring sensor confirms removal.");
      }
    });

    // Observe validated, decrypted reports without consuming them. In particular, Z-Wave JS can
    // initialise Notification values to idle during an interview. That is not a closed-door report.
    void driver.waitForCommand(command => {
      try {
        inspectReport(command, (nodeId, values) => queueMicrotask(() => onReport(nodeId, values)));
      } catch {
        error("A Z-Wave report could not be interpreted.");
      }
      return false;
    }, undefined, stdoutAbort.signal, { consume: false }).catch(() => {
      if (!stopping) error("The Ring sensor report listener stopped unexpectedly.");
    });
  });

  for (const event of ["ready", "interview completed", "value updated", "value added", "value removed", "dead", "alive", "wake up", "sleep"]) {
    driver.on(`node ${event}`, publish);
  }

  input = createInterface({ input: inputStream, terminal: false });
  input.on("line", line => {
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      error("The driver received an invalid request.");
      return;
    }
    void handle(message).catch(failure => {
      // Keep driver errors, configuration values, and PINs out of Indigo's log.
      if (message?.command === "include" || message?.command === "exclude") {
        error(failure.message);
      } else {
        error("The Z-Wave request could not be completed.");
      }
    });
  });
  input.on("close", () => void stop(0));
  if (inputStream === process.stdin) {
    process.once("SIGINT", () => void stop(0));
    process.once("SIGTERM", () => void stop(0));
  }
  outputStream.on("error", () => void stop(1));

  status("Opening the Z-Wave USB stick.");
  try {
    await driver.start();
  } catch {
    if (!stopping) {
      error("Could not open the Z-Wave stick. Confirm the serial port and close any app already using this stick.");
      await stop(1);
    }
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    await serve(readOptions());
  } catch {
    writeMessage(process.stdout, { type: "error", message: "The Z-Wave driver could not start. Check its setup and selected USB port." });
    process.exitCode = 1;
  }
}
