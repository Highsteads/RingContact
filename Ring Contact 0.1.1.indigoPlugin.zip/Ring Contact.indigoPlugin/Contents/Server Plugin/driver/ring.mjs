import { createHash } from "node:crypto";
import { CommandClasses, NodeStatus, SecurityClass } from "@zwave-js/core";
import {
  NotificationCCReport,
  Security2CCMessageEncapsulation,
  isEncapsulatingCommandClass,
  isMultiEncapsulatingCommandClass,
} from "zwave-js";

const ringGen2Products = new Set([0x0301, 0x0401, 0x0601]);
const batteryLevel = { commandClass: CommandClasses.Battery, endpoint: 0, property: "level" };

export function isRingContact(node) {
  return node?.manufacturerId === 0x0346
    && node.productType === 0x0201
    && ringGen2Products.has(node.productId);
}

export function nodeIdentity(node) {
  return node.dsk ? createHash("sha256").update(node.dsk).digest("hex") : null;
}

export function decodeNotification(type, event, parameters) {
  if (type === 0x06) {
    if (event === 0x16) return { contact: true };
    if (event === 0x17) return { contact: false };
  }
  if (type === 0x07) {
    if (event === 0x01 || event === 0x02) return { contact: true };
    if (event === 0x03) return { cover: true };
    if (event === 0x0b) return { magnetic: true };
    if (event === 0x00 && parameters instanceof Uint8Array && parameters.length > 0) {
      const cleared = parameters[0];
      if (cleared === 0x01 || cleared === 0x02) return { contact: false };
      if (cleared === 0x03) return { cover: false };
      if (cleared === 0x0b) return { magnetic: false };
    }
  }
  return null;
}

export function inspectReport(command, emit, authenticated = false) {
  if (command instanceof Security2CCMessageEncapsulation) {
    authenticated = command.securityClass === SecurityClass.S2_Authenticated;
  }
  if (isEncapsulatingCommandClass(command)) {
    if (command.encapsulated) inspectReport(command.encapsulated, emit, authenticated);
    return;
  }
  if (isMultiEncapsulatingCommandClass(command)) {
    for (const inner of command.encapsulated) inspectReport(inner, emit, authenticated);
    return;
  }
  if (authenticated && command instanceof NotificationCCReport && command.endpointIndex === 0) {
    const values = decodeNotification(command.notificationType, command.notificationEvent, command.eventParameters);
    if (values) emit(command.nodeId, values);
  }
}

export function describeNode(node, observed) {
  const identity = nodeIdentity(node);
  const securityClass = node.getHighestSecurityClass();
  const trusted = securityClass === SecurityClass.S2_Authenticated && identity !== null;
  const battery = node.getValue(batteryLevel);
  const knownTamper = observed?.cover === true || observed?.magnetic === true
    ? true
    : observed?.cover === false || observed?.magnetic === false ? false : null;
  return {
    nodeId: node.id,
    manufacturerId: node.manufacturerId,
    productType: node.productType,
    productId: node.productId,
    name: node.name || "Ring Contact",
    identity,
    contact: trusted ? (observed?.contact ?? null) : null,
    tamper: trusted ? knownTamper : null,
    battery: Number.isInteger(battery) && battery >= 0 && battery <= 100 ? battery : null,
    available: trusted && node.status !== NodeStatus.Dead,
    security: typeof securityClass === "number"
      ? ({
          [SecurityClass.S2_Authenticated]: "S2 Authenticated",
          [SecurityClass.S2_AccessControl]: "S2 Access Control",
          [SecurityClass.S2_Unauthenticated]: "S2 Unauthenticated",
          [SecurityClass.S0_Legacy]: "S0",
          [SecurityClass.None]: "None",
        }[securityClass] ?? null)
      : null,
  };
}
