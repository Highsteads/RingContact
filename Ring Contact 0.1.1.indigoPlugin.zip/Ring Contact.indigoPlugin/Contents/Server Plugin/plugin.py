"""Expose securely paired Ring contact sensors as normal Indigo devices."""

from pathlib import Path
from queue import Empty, SimpleQueue
import re
import subprocess
from time import monotonic

import indigo

from driver_runtime import (
    DriverInstallation, DriverProcess, check_node, find_node, port_is_busy, runtime_path,
    serial_ports,
)


DRIVER_SOURCE = Path(__file__).resolve().parent / "driver"
RING_PRODUCT_IDS = {0x0301, 0x0401, 0x0601}
SENSOR_TYPE = "ringContact"
DEVICE_FOLDER = "Ring"
PAIRING_REQUIRED = "Wait for the 10 Pro to connect before using this menu."
RETRY_SECONDS = 12
CONTROLLER_TIMEOUT = 45
INSTALL_TIMEOUT = 300


class Plugin(indigo.PluginBase):
    def __init__(self, pluginId, pluginDisplayName, pluginVersion, pluginPrefs):
        super().__init__(pluginId, pluginDisplayName, pluginVersion, pluginPrefs)
        self.requests = SimpleQueue()
        self.data_dir = Path.home() / "Library" / "Application Support" / pluginId
        self.settings = self._read_settings(pluginPrefs)
        self.runtime = None
        self.installation = None
        self.install_deadline = 0
        self.driver = None
        self.driver_deadline = 0
        self.home_id = None
        self.next_attempt = 0
        self.last_problem = None

    def startup(self):
        self.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.runtime = runtime_path(DRIVER_SOURCE, self.data_dir)

    @staticmethod
    def _read_settings(values):
        port = str(values.get("serialPort") or "").strip()
        node_path = str(values.get("nodePath") or "").strip()
        return port, node_path

    def serialPortList(self, filter="", valuesDict=None, typeId="", targetId=0):
        ports = serial_ports()
        selected, _ = self._read_settings(valuesDict or self.pluginPrefs)
        if selected and selected not in ports:
            ports.append(selected)
        return [("", "Choose the 10 Pro USB port")] + [(port, port) for port in ports]

    def validatePrefsConfigUi(self, valuesDict):
        port, node_path = self._read_settings(valuesDict)
        if port and not re.fullmatch(r"/dev/(?:cu|tty)\.[a-zA-Z0-9_.-]+", port):
            return False, valuesDict, indigo.Dict({"serialPort": "Choose the 10 Pro USB port."})
        if node_path:
            try:
                find_node(node_path)
            except RuntimeError as exc:
                return False, valuesDict, indigo.Dict({"nodePath": str(exc)})
        return True, valuesDict

    def closedPrefsConfigUi(self, valuesDict, userCancelled):
        if not userCancelled:
            self.requests.put(("configure", self._read_settings(valuesDict)))

    def installDriver(self):
        self.requests.put(("install", None))

    def pairSensor(self, valuesDict, typeId):
        pin = str(valuesDict.get("pin") or "").strip()
        if not re.fullmatch(r"[0-9]{5}", pin):
            return False, valuesDict, indigo.Dict({"pin": "Enter the five digits printed below the QR code."})
        if self.home_id is None:
            return False, valuesDict, indigo.Dict({"showAlertText": PAIRING_REQUIRED})
        self.requests.put(("send", {"command": "include", "pin": pin}))
        valuesDict["pin"] = ""
        return True, valuesDict

    def excludeSensor(self, valuesDict, typeId):
        if self.home_id is None:
            return False, valuesDict, indigo.Dict({"showAlertText": PAIRING_REQUIRED})
        self.requests.put(("send", {"command": "exclude"}))
        return True, valuesDict

    def cancelPairing(self):
        self.requests.put(("send", {"command": "cancel"}))

    def refreshSensors(self):
        self.requests.put(("send", {"command": "snapshot"}))

    def deviceStartComm(self, dev):
        if self.home_id is not None:
            self.requests.put(("send", {"command": "snapshot"}))

    def runConcurrentThread(self):
        try:
            self._mark_disconnected("Waiting for the Z-Wave driver")
            while True:
                self._handle_requests()
                self._check_installation()
                self._check_driver()
                if self.driver is None and self.installation is None and monotonic() >= self.next_attempt:
                    self._start_driver()
                self.sleep(0.15)
        except self.StopThread:
            pass
        finally:
            try:
                self._stop_driver()
            finally:
                if self.installation is not None:
                    self.installation.close()
                    self.installation = None

    def _handle_requests(self):
        for _ in range(50):
            try:
                action, data = self.requests.get_nowait()
            except Empty:
                break
            if action == "configure" and data != self.settings:
                self.settings = data
                self._stop_driver()
                self._mark_disconnected("Waiting for the Z-Wave driver")
                self.next_attempt = 0
                self.last_problem = None
            elif action == "install":
                self._install_driver()
            elif action == "send":
                self._send(data)

    def _install_driver(self):
        if self.installation is not None:
            self.logger.info("Driver installation is already in progress.")
            return
        _, requested_node = self.settings
        try:
            node = find_node(requested_node)
            self.installation = DriverInstallation(DRIVER_SOURCE, self.data_dir, node)
        except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
            self.logger.error("Could not install the Z-Wave driver. %s", exc)
            return
        self.install_deadline = monotonic() + INSTALL_TIMEOUT
        self.logger.info("Installing the local Z-Wave driver. This may take a few minutes.")

    def _check_installation(self):
        installation = self.installation
        if installation is None:
            return
        finished = installation.process.poll()
        if finished is None and monotonic() < self.install_deadline:
            return
        try:
            if finished is None:
                raise RuntimeError(f"Installation timed out. See {installation.log_path}.")
            if finished != 0:
                raise RuntimeError(f"See {installation.log_path}.")
            self._stop_driver()
            self._mark_disconnected("Starting the Z-Wave driver")
            installation.finish()
            self.next_attempt = 0
            self.last_problem = None
            self.logger.info("Z-Wave driver installed.")
        except (OSError, RuntimeError) as exc:
            self.logger.error("Could not finish installing the Z-Wave driver. %s", exc)
        finally:
            installation.close()
            self.installation = None

    def _start_driver(self):
        port, requested_node = self.settings
        self.next_attempt = monotonic() + RETRY_SECONDS
        try:
            if not port:
                raise RuntimeError("Open Configure and choose the USB port for the 10 Pro.")
            if not (self.runtime / ".ready").is_file():
                raise RuntimeError("Choose Install or Repair Driver from the Ring Contact menu.")
            if not (self.runtime / "node_modules" / "zwave-js" / "package.json").is_file():
                raise RuntimeError("The Z-Wave driver files are incomplete. Choose Install or Repair Driver.")
            if not Path(port).exists():
                raise RuntimeError("The selected USB port is missing. Check that the 10 Pro is connected.")
            if port_is_busy(port):
                raise RuntimeError("Another program is using that USB stick. Choose the dedicated 10 Pro port.")
            node = find_node(requested_node)
            check_node(node)
            self.driver = DriverProcess(self.runtime, node, port, self.data_dir / "zwave-store")
        except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
            self._report_problem(str(exc))
            return
        self.driver_deadline = monotonic() + CONTROLLER_TIMEOUT
        self.logger.info("Connecting to the Z-Wave stick at %s.", port)

    def _check_driver(self):
        if self.driver is None:
            return
        for update in self.driver.updates():
            try:
                self._handle_update(update)
            except Exception:
                self.logger.exception("Could not apply a Z-Wave update to Indigo.")
        if self.driver.process.poll() is not None:
            self._driver_lost("The Z-Wave driver disconnected. Check the 10 Pro and the selected port.")
        elif self.home_id is None and monotonic() >= self.driver_deadline:
            self._driver_lost("The stick did not answer. Try the other 10 Pro port in Configure.")

    def _report_problem(self, message):
        if message != self.last_problem:
            self.last_problem = message
            self.logger.warning(message)

    def _driver_lost(self, message):
        self._stop_driver()
        self._mark_disconnected("Z-Wave driver disconnected")
        self.next_attempt = monotonic() + RETRY_SECONDS
        self._report_problem(message)

    def _stop_driver(self):
        driver = self.driver
        self.driver = None
        self.home_id = None
        if driver is not None:
            driver.close()

    def _send(self, command):
        if self.driver is None or self.home_id is None:
            self.logger.warning(PAIRING_REQUIRED)
            return
        try:
            self.driver.send(command)
        except (OSError, ValueError):
            self._driver_lost("The Z-Wave driver disconnected. Check the 10 Pro and the selected port.")

    def _handle_update(self, update):
        kind = update.get("type")
        if kind in ("status", "error"):
            message = update.get("message")
            if isinstance(message, str):
                if kind == "error":
                    self._report_problem(message)
                else:
                    self.logger.info(message)
            return
        home_id = update.get("homeId")
        if not isinstance(home_id, str) or not home_id:
            return
        if kind == "snapshot":
            if self.home_id != home_id:
                self.logger.info("Z-Wave stick is ready. Choose Add Ring Sensor when ready to pair.")
            self.home_id = home_id
            self.last_problem = None
            nodes = update.get("nodes") or []
            reported = set()
            for node in nodes:
                if self._is_ring(node):
                    reported.add(node["nodeId"])
                    self._apply_node(home_id, node, live=False)
            for dev in indigo.devices.iter("self"):
                if not dev.enabled or dev.pluginProps.get("retired"):
                    continue
                device_home = dev.pluginProps.get("homeId")
                if device_home != home_id or dev.pluginProps.get("nodeId") not in reported:
                    self._set_unavailable(dev, "Sensor not found on the connected stick")
        elif home_id == self.home_id and kind == "node" and self._is_ring(update.get("node")):
            self._apply_node(home_id, update["node"], live=True)
        elif home_id == self.home_id and kind == "removed":
            dev = self._find_device(home_id, update.get("nodeId"))
            if dev is not None:
                props = dict(dev.pluginProps)
                props["retired"] = True
                dev.replacePluginPropsOnServer(props)
                self._set_unavailable(dev, "Sensor removed from the Z-Wave network")

    @staticmethod
    def _is_ring(node):
        return (isinstance(node, dict)
                and type(node.get("nodeId")) is int
                and node.get("manufacturerId") == 0x0346
                and node.get("productType") == 0x0201
                and node.get("productId") in RING_PRODUCT_IDS)

    def _find_device(self, home_id, node_id):
        for dev in indigo.devices.iter("self"):
            props = dev.pluginProps
            if props.get("homeId") == home_id and props.get("nodeId") == node_id and not props.get("retired"):
                return dev
        return None

    @staticmethod
    def _ring_folder_id():
        for folder in indigo.devices.folders:
            if folder.name.casefold() == DEVICE_FOLDER.casefold():
                return folder.id
        try:
            return indigo.devices.folder.create(DEVICE_FOLDER).id
        except ValueError as exc:
            if str(exc) == "NameNotUniqueError":
                return indigo.devices.folders[DEVICE_FOLDER].id
            raise

    def _make_device(self, home_id, node_id):
        existing_names = {dev.name.casefold() for dev in indigo.devices}
        name = f"Ring Contact {node_id}"
        suffix = 2
        while name.casefold() in existing_names:
            name = f"Ring Contact {node_id} ({suffix})"
            suffix += 1
        dev = indigo.device.create(
            protocol=indigo.kProtocol.Plugin,
            address=f"{home_id}:{node_id}",
            name=name,
            folder=self._ring_folder_id(),
            pluginId=self.pluginId,
            deviceTypeId=SENSOR_TYPE,
            props={
                "homeId": home_id, "nodeId": node_id,
                "SupportsOnState": True, "SupportsSensorValue": False,
                "SupportsBatteryLevel": True, "SupportsStatusRequest": False,
                "AllowOnStateChange": False,
            },
        )
        dev.configured = True
        dev.replaceOnServer()
        return indigo.devices[dev.id]

    def _apply_node(self, home_id, node, live):
        dev = self._find_device(home_id, node["nodeId"])
        if dev is None:
            dev = self._make_device(home_id, node["nodeId"])
        if not dev.enabled:
            return
        identity = node.get("identity")
        previous_identity = dev.pluginProps.get("identity")
        if previous_identity and identity != previous_identity:
            self._set_unavailable(dev, "Waiting to verify this sensor")
            return
        if identity and not previous_identity:
            props = dict(dev.pluginProps)
            props["identity"] = identity
            dev.replacePluginPropsOnServer(props)
        security = node.get("security")
        if not security:
            self._set_unavailable(dev, "Waiting to verify secure pairing")
            return
        if security != "S2 Authenticated":
            self._set_unavailable(dev, "Pair this sensor again using its five-digit code")
            return
        if node.get("available") is False:
            self._set_unavailable(dev, "Sensor unavailable")
            return
        self._write_state(dev, "available", True)
        contact = node.get("contact")
        if type(contact) is bool:
            display = "Open" if contact else "Closed"
            was_known = dev.states.get("contactKnown") is True
            self._write_state(dev, "contactDisplay", display)
            self._write_state(dev, "contactKnown", True)
            if dev.errorState:
                dev.setErrorStateOnServer(None)
            if not was_known or dev.states.get("onOffState") != contact:
                dev.updateStateOnServer(
                    "onOffState", contact, uiValue=display, triggerEvents=live and was_known,
                )
        else:
            self._write_state(dev, "contactKnown", False)
            self._write_state(dev, "contactDisplay", "Unknown")
            self._write_error(dev, "Waiting for the sensor to report open or closed")
        tamper = node.get("tamper")
        if type(tamper) is bool:
            self._write_state(dev, "tamper", tamper, live)
        battery = node.get("battery")
        if type(battery) is int and 0 <= battery <= 100:
            self._write_state(dev, "batteryLevel", battery, live)

    @staticmethod
    def _write_state(dev, key, value, trigger_events=False):
        if dev.states.get(key) != value:
            dev.updateStateOnServer(key, value, triggerEvents=trigger_events)

    @staticmethod
    def _write_error(dev, message):
        if dev.errorState != message:
            dev.setErrorStateOnServer(message)

    def _set_unavailable(self, dev, message):
        self._write_state(dev, "contactKnown", False)
        self._write_state(dev, "contactDisplay", "Unknown")
        self._write_state(dev, "available", False)
        self._write_error(dev, message)

    def _mark_disconnected(self, message):
        for dev in indigo.devices.iter("self"):
            if dev.enabled and not dev.pluginProps.get("retired"):
                self._set_unavailable(dev, message)
