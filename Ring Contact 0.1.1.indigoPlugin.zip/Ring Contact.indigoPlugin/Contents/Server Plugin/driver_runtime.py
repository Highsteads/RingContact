"""Install and run the local Z-Wave driver for the Indigo plugin."""

import hashlib
import json
import os
from pathlib import Path
from queue import Empty, SimpleQueue
import shutil
import subprocess
import tempfile
from threading import Thread


NODE_CANDIDATES = (
    "/opt/homebrew/opt/node@22/bin/node",
    "/opt/homebrew/bin/node",
    "/usr/local/opt/node@22/bin/node",
    "/usr/local/bin/node",
)


def find_node(configured_path):
    candidates = (configured_path,) if configured_path else (*NODE_CANDIDATES, shutil.which("node"))
    for candidate in candidates:
        if not candidate:
            continue
        path = Path(candidate).expanduser()
        if path.is_absolute() and path.is_file() and os.access(path, os.X_OK):
            return path
    raise RuntimeError("Install Node.js 22 or later on the Indigo Mac, or set its path in Configure.")


def node_environment(node):
    env = os.environ.copy()
    env["PATH"] = os.pathsep.join((str(node.parent), os.defpath, env.get("PATH", "")))
    return env


def check_node(node):
    result = subprocess.run(
        [str(node), "--version"], capture_output=True, text=True, timeout=5, check=True
    )
    version = result.stdout.strip().removeprefix("v")
    major, _, remainder = version.partition(".")
    if not remainder or not major.isdecimal() or int(major) < 22:
        raise RuntimeError("Ring Contact requires Node.js 22 or later.")


def serial_ports():
    return sorted(str(path) for path in Path("/dev").glob("cu.*")
                  if path.name.startswith(("cu.usb", "cu.SLAB_", "cu.wchusb")))


def port_is_busy(port):
    if not Path("/usr/sbin/lsof").is_file():
        return False
    alternate = port.replace("/dev/cu.", "/dev/tty.", 1)
    if alternate == port:
        alternate = port.replace("/dev/tty.", "/dev/cu.", 1)
    ports = [candidate for candidate in (port, alternate) if Path(candidate).exists()]
    if not ports:
        return False
    try:
        result = subprocess.run(
            ["/usr/sbin/lsof", "-t", *ports], capture_output=True, text=True, timeout=3
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return any(line.isdecimal() for line in result.stdout.splitlines())


class DriverInstallation:
    def __init__(self, source, data_dir, node):
        self.stage = None
        self.process = None
        self.destination = runtime_path(source, data_dir)
        self.log_path = data_dir / "driver-install.log"

        check_node(node)
        npm = node.with_name("npm")
        if not npm.is_file():
            raise RuntimeError(f"Could not find npm beside Node.js at {node.parent}.")
        self.destination.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.stage = Path(tempfile.mkdtemp(prefix="setup-", dir=self.destination.parent))
        try:
            for path in driver_files(source):
                shutil.copy2(path, self.stage / path.name)
            log_descriptor = os.open(self.log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(log_descriptor, "wb") as log:
                self.process = subprocess.Popen(
                    [str(npm), "ci", "--omit=dev", "--no-audit", "--no-fund",
                     "--cache", str(data_dir / "npm-cache")],
                    cwd=self.stage, env=node_environment(node), stdin=subprocess.DEVNULL,
                    stdout=log, stderr=subprocess.STDOUT,
                )
        except Exception:
            self.close()
            raise

    def finish(self):
        if self.process.poll() != 0:
            raise RuntimeError(f"Driver installation failed. See {self.log_path}.")
        backup = Path(tempfile.mkdtemp(prefix="backup-", dir=self.destination.parent))
        saved = backup / "previous"
        try:
            (self.stage / ".ready").touch()
            if self.destination.exists():
                self.destination.rename(saved)
            self.stage.rename(self.destination)
        except Exception:
            if saved.exists():
                saved.rename(self.destination)
            raise
        finally:
            if not saved.exists() or self.destination.exists():
                shutil.rmtree(backup, ignore_errors=True)

    def close(self):
        if self.process is not None and self.process.poll() is None:
            stop_process(self.process)
        if self.stage is not None:
            shutil.rmtree(self.stage, ignore_errors=True)


def driver_files(source):
    modules = sorted(path for path in source.glob("*.mjs") if not path.name.endswith(".test.mjs"))
    return [source / "package.json", source / "package-lock.json", *modules]


def runtime_path(source, data_dir):
    fingerprint = hashlib.sha256()
    for path in driver_files(source):
        fingerprint.update(path.name.encode("utf-8"))
        fingerprint.update(b"\0")
        fingerprint.update(path.read_bytes())
    return data_dir / "runtime" / fingerprint.hexdigest()[:16]


class DriverProcess:
    def __init__(self, runtime, node, port, store):
        store.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.messages = SimpleQueue()
        self.process = subprocess.Popen(
            [str(node), str(runtime / "main.mjs"), "--port", port, "--store", str(store)],
            cwd=runtime, env=node_environment(node), stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
            encoding="utf-8", errors="replace", bufsize=1,
        )
        self.reader = Thread(target=self._read, name="Ring Contact driver reader", daemon=True)
        self.reader.start()

    def _read(self):
        for line in self.process.stdout:
            try:
                message = json.loads(line)
            except (ValueError, UnicodeError):
                continue
            if isinstance(message, dict):
                self.messages.put(message)

    def send(self, command):
        self.process.stdin.write(json.dumps(command, ensure_ascii=True) + "\n")
        self.process.stdin.flush()

    def updates(self):
        for _ in range(200):
            try:
                yield self.messages.get_nowait()
            except Empty:
                break

    def close(self):
        if self.process.poll() is None:
            try:
                self.send({"command": "stop"})
            except (OSError, ValueError):
                pass
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                stop_process(self.process)
        self.reader.join(timeout=2)
        self.process.stdin.close()
        if not self.reader.is_alive():
            self.process.stdout.close()


def stop_process(process):
    process.terminate()
    try:
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()
